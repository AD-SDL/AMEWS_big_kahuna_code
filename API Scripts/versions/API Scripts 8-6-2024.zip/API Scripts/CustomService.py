import sys, os, string, math, re, random, numpy, copy
import json, time, clr, shutil
from datetime import datetime
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import xml.etree.ElementTree as ET
from lxml import etree
from System.Reflection import Assembly, ReflectionTypeLoadException
import System
import System.Collections.Generic
clr.AddReference('System.Drawing')
from System.Drawing import Point
from a10_sila import CustomAS10  


def CustomVerbosity(): # 1 for verbose script
        return 1 


def class_contents(c):
    print("\nContents for class %s" % c)
    d = dir(c)

    for item in d:
        if not item.startswith("__"):  
            try: 
                if callable(getattr(c, item)):
                    print(f"Function: {item}()")
            except:
                print(f"Unclassified: {item}")
            
    for item in d:
        if not item.startswith("__"):  
            try: 
                if not callable(getattr(c, item)):
                    value = getattr(c, item)
                    print(f"Attribute: {item}: {value}")
            except:
                pass

class CustomUtils: # common LS handling utilities 
    
    def __init__(self):
        self.wells = []
        self.values = []
        
    def well2tuple(self, well):
        letter = well[0].upper()
        col = int(well[1:])
        row = ord(letter) - ord('A') + 1
        return (row,col)
    
    def well2point(self, well):
        row, col = self.well2tuple(well)
        return Point(row ,col)
    
    def tuple2well(self, row, col):
        return "%s%d" % (chr(64+row), col)
    
    def invert_well(self, well):
          row, col = self.well2tuple(well)
          return self.tuple2well(col, row)   
        
    def WellRangeFromString(self, range_string): # defines and fills rectangular range
        cells = range_string.split(':')
        (start_row, start_col) = self.well2tuple(cells[0])
        
        if len(cells) == 1:
            return self.WellRange(start_row, start_col, 1, 1)
            
        (last_row, last_col) = self.well2tuple(cells[1])
        
        if last_row < start_row:
            t = start_row
            start_row = last_row
            last_row = t
            
        if last_col < start_col:
            t = start_col
            start_col = last_col
            last_col = t
            
        row_count = last_row - start_row + 1
        col_count = last_col - start_col + 1
        
        return self.WellRange(start_row, start_col, row_count, col_count)
    
    def WellRange(self, row, col, row_count, col_count): # fills rectangular range
        n = row_count * col_count
        self.wells = []
        retval = System.Collections.Generic.List[System.Tuple[System.Int32, System.Int32]](n)
        for r in range(row, row + row_count):
            for c in range(col, col + col_count):
                retval.Add(System.Tuple[System.Int32, System.Int32](r, c))
                self.wells.append((r,c))
        return retval 

    def UniformValues(self, count, value): # creates uniform dicrete map of doubles
        self.values = [] 
        retval = System.Collections.Generic.List[System.Double](count)
        for i in range(count):
            retval.Add(value)
            self.values.append(value)
        return retval
    
    def UniformObjects(self, count, value): # creates uniform dicrete map of object  - use them in parameter maps
        self.values = [] 
        retval = System.Collections.Generic.List[System.Object](count)
        for i in range(count):
            retval.Add(value)
            self.values.append(value)
        return retval
    
    def report_wells_values(self): # reports well and discrete map ranges
        ws = ';'.join([str(t) for t in self.wells])        
        vs = ';'.join([str(t) for t in self.values])    
        return (ws,vs)

class PromptsFile:   # prompt xml file === initial state of well is either "None" or "Covered"       
   
    def __init__(self):
        self.prompts = ""
        self.plates =  ""
        self.sources = ""
        self.positions = []
        
    def PromptsPart1(self): # replacement in the exemplar prompt xml file
        with open(r'promptspart1.xml', 'r') as file:
            data = file.read()
            data = data.replace('<!-- Initial library states -->', self.plates[:-1])
            data = data.replace('<!-- Initial source states -->', self.sources[:-1])
        return data

    def AddInitialLibraryState(self, library_id, state="None"): # adds ID's of plate libraries with their initial states
        self.plates += "[%d:%s];"  %  (library_id, state)

    def AddInitialSourceState(self,  # adds source positions
                              position, 
                              state="None", # None or Covered
                              check = True, # check if position is in positions already
                              ):
        if not position: return
            
        if check: 
            check = position in self.positions
            
        if not check:
            self.sources  += "[%s:%s];"  %  (position, state)
            self.positions.append(position)

    def Write(self, path): # writes into the prompt xml file
        self.prompts = self.PromptsPart1()
        with open(path, 'w') as file:
            file.write(self.prompts)

class ChemFile: # chemcial manager xml file, consists of four sections that are put together

    def __init__(self):
        self.chem_part_1 = ""
        self.chem_part_2 = ""
        self.chem_part_3 = ""
        self.chem_part_4 = ""
        self.verbose = CustomVerbosity()
        
    def ChemPart1(self, chemicals, libs, dispense): # combines three sections
        with open('chempart1.xml', 'r') as file:
            data = file.read()
            data = data.replace('<!-- Chemicals Part -->', chemicals)
            data = data.replace('<!-- Libraries Part -->', libs)
            data = data.replace('<!-- Dispense modes part -->', dispense)
        return data

    def ChemPart2(self): # add as a chemical
        with open('chempart2.xml', 'r') as file:
            data = re.sub(r'^\s*<\?xml.*?\?>\s*', '', file.read())
            root = etree.fromstring(data)
            data = etree.tostring(root, pretty_print=True).decode('utf-8')
            if self.verbose: 
                #print(data) 
                pass
            return data

    def ChemPart3(self, library_id, name, rows, cols, kind, position): # add ID'd substrate library
        with open('chempart3.xml', 'r') as file:
            data = file.read()
            data = data.replace('<!-- LibraryID -->', str(library_id))
            data = data.replace('<!-- Name -->', name)
            data = data.replace('<!-- NumOfRows -->', str(rows))
            data = data.replace('<!-- NumOfCols -->', str(cols))
            data = data.replace('<!-- SubstrateType -->', kind)
            data = data.replace('<!-- SubstratePosition -->', position)
        return data
        
    def ChemPart4(self, name, mode): # add dispense modes for chemicals
        with open('chempart4.xml', 'r') as file:
            data = file.read()
            data = data.replace('%%Chemical Name%%', name)
            data = data.replace('%%Dispense Mode%%', mode)
        return data


    def AddChemical(self, name, mode): # adds a chemical
        self.chem_part_2 += self.ChemPart2()
        self.chem_part_4 += self.ChemPart4(name, mode)

    def AddLibrary(self, library_id, name, rows, cols, kind, position): # adds a library
        self.chem_part_3 += self.ChemPart3(library_id, 
                                      name, 
                                      rows, 
                                      cols, 
                                      kind, 
                                      position
                                      )

    def Write(self, path: str): # writes into chemical manager xml file
        self.chem_part_1 = self.ChemPart1(self.chem_part_2, self.chem_part_3, self.chem_part_4)
        with open(path, 'w') as file:
            file.write(self.chem_part_1)
        os.remove('chempart2.xml')

class CustomLS10: # LS API wrapper calls
    
    def __init__(self):
        self.stamp = self.stamp()
        self.cmap = plt.get_cmap("nipy_spectral")
        self.path = os.getcwd()
        print("writes ChemicalManager and prompt XML files in %s" % self.path)
        self.chemfile = ChemFile()
        self.promptsfile = PromptsFile()
        self.units = "ul" 
        self.map_count = 1
        self.lib_count = 0
        self.project = "auto"
        self.name = "" 
        self.ID = 0
        self.sources = {}
        self.chem = {}
        self.sdf = pd.DataFrame()
        self.utils = CustomUtils()
        self.status = 0
        self.error_message = ""
        self.verbose = CustomVerbosity()
        self.transfer = 1
        self.pt = CustomPlateManager()
        self.tm = CustomTransferMap() 
        self.pause_codebook = {}
        self.dir = self.path

        ls_path = "C:/LSAPI/Libs/LSAPI.dll"
        if not os.path.exists(ls_path):
            print("Cannot find assembly LSAPI.dll")
            sys.exit(1)
    
        try:
            clr.AddReference(ls_path)
        except Exception as e:
            print("cannot add LSAPI.dll")
            print(e)
            sys.exit(1)
   
        try: 
            assembly = Assembly.LoadFile(ls_path)
        except Exception as e:
            print("failed to load assembly LSAPI.dll")
            print(e)
            sys.exit(1)
        
        # self.inspect_assembly(assembly)   # use to inspect assembly
        import LS_API
        
        self.ls =  LS_API.LibraryStudioWrapper
        self.units = self.units.lower() # added to prevent using mL etc.
       
        self.TAGS = {"skip":"SkipMap",                          # short codes for common tags
                     "1tip":"SyringePump,SingleTip",
                     "Etip":"SyringePump,ExtSingleTip",
                     "chaser":"Chaser",
                     "4tip":"4Tip"
                     }
        
        self.PTYPES = ["Temperature", "Time", "Rate", "Number", "Text", "Stir Rate", "Temperature Rate"]
    
    def  inspect_assembly(self, assembly):   # inspect modules in a .NET asssembly
        try:
            print("Types in the assembly:")
            for type in assembly.GetTypes():
                print(type.FullName)
        except ReflectionTypeLoadException as e:
            print("Error loading types from assembly:")
            for loader_exception in e.LoaderExceptions:
                print(loader_exception)
        except Exception as e:
            print("An unexpected error occurred while inspecting the assembly:")
            print(e)
            
    def create_lib(self, name): # create a new LS library
        if name is None:
            name = "auto_design"
        if self.verbose:
            print("create design %s in project %s" % (name,self.project))
        status = self.ls.CreateNewDesign(name, self.project,"", "","", "", "", "created on %s" % self.stamp )
        self.HandleStatus(status)
        self.name = name
        
    def van_der_corput(self, n, base=6): # van der Corput sequence in a given base  to pick colors  
        vdc, denom = 0, 1
        while n:
            n, remainder = divmod(n, base)
            denom *= base
            vdc += remainder/denom
        return vdc
        
    def test_van_der_corput(self): # test of color picking
        c = self.rgb_to_uint(0.5,0.5,0.5,1)
        print("gray: => (128,128,128) %d" % c)
        for n in range(0,13):
            x = self.van_der_corput(n)
            r, g, b, a = self.cmap(1-x)
            c = self.rgb_to_uint(r,g,b,a)
            r = int(r * 255)
            g = int(g * 255)
            b = int(b * 255)
            print("%d: %.3f => (R=%d, G=%d, B=%d) %d" % (n,x,r,g,b,c))
        sys.exit()
        
    def rgb_to_uint(self, r, g, b, a=0): # RGB to an integer, ignore alpha, 24 bit version, inverted
        R = int(r * 255)
        G = int(g * 255)
        B = int(b * 255)   
        return (B << 16) + (G << 8) + R
    
    def uint_to_RGB(self, uint): # integer to RGB 0..255 scale
        R = uint & 255
        G = (uint >> 8) & 255
        B = (uint >> 16) & 255
        return (R, G, B)
    
    def closest_color(self,uint):
        R, G, B = self.uint_to_RGB(uint)
        m = float('inf')
        c = None
        for name, hex in mcolors.CSS4_COLORS.items():
            r, g, b = mcolors.hex2color(hex)
            r, g, b = [int(x * 255) for x in (r, g, b)]
            d = abs(r - R) + abs(g - G) + abs (b - B) 
            if d < m:
                m = d
                c = name
        return c
        
    def index2color(self,index): # index 0,1....  to (0,1) color scale
        q = self.van_der_corput(index)
        return self.rgb_to_uint(*self.cmap(1-q))
        
    def to_tag(self,code): # tag code word to a full tag
        if "_" in code: 
            code = code.split("_")
            key = code[1].upper()
            base = code[0]
        else:
            base = code
            key = ""
            
        if len(base) == 0: base="Processing"
        if base not in self.TAGS: 
            return ""
        else:
            base = self.TAGS[base]
        if "S" in key: base+=",Backsolvent"
        if "L" in key: base+=",LookAhead"
        if "W" in key: base+=",SkipWash"
        if "I" in key: base+=",Image"
        return base
    
    def HandleStatus(self, status): # error messages
        self.status = status
        self.error_message = None
        if status<0:
            if status == -1:
                self.error_message = "Unidentified error"
            else:
                self.error_message = self.ls.GetErrorMessage(status)
            print(">> LS ERROR = %d : %s" % (self.status,self.error_message))
    
    def stamp(self): # daytime stamp
        now = datetime.now()
        return now.strftime('%Y%m%d_%H%M%S')
        
    def xml(self, type): # name xml files
        return "%s_%s.xml" % (type,self.stamp)
    
    def add_plate(self, plate, state="None"): # add substrate
        kind, position, rows, cols = self.pt.get(plate)
        color = self.index2color(self.lib_count)
        status = self.ls.AddLibrary(plate, 
                           nRows = rows, 
                           nCols = cols, 
                           color = color,
                           )
        self.HandleStatus(status)
        if self.verbose:
            print("added %dx%d substrate %s, color = %d (%s)" % 
                  (rows,cols,plate,color,self.closest_color(color)))
        self.lib_count += 1
        
    def add_all_plates(self): # adds all non-source plates in the plate library
        if self.verbose:
            print("\nadds all plates:")            
        for plate in self.pt.plates:
           if "source" not in plate:
                self.add_plate(plate)    
    
    def AddSource(self,source,chem,kind,position,color,row,col,volume=-1): # adds a new chemical/source to chemical manager file (part 2)
        root = ET.Element("Symyx.AutomationStudio.Core.ChemicalManager.Chemical")
        
        if chem == "solvent": 
            t = "stBackingSolvent"
            row, col = 0, 0
            kind, position = None, None
            vr = "Syringe 1"
            vp = "1"
        else:
            t = "stNormal"
            vr = None
            vp = "0"
            
        if chem == source:
            row, col = 0, 0
            t = "stPlate"
            
        if volume<0:
           u = "undefined"
        else:
           u = self.units

        ET.SubElement(root, "Name").text = chem
        ET.SubElement(root, "AmountLeft").text = str(volume)
        ET.SubElement(root, "Color").text = str(color)
        ET.SubElement(root, "Column").text = str(col)
        ET.SubElement(root, "Columns").text = "0"
        ET.SubElement(root, "Empty").text = "False"
        ET.SubElement(root, "Questionable").text = "False"
        ET.SubElement(root, "Row").text = str(row)
        ET.SubElement(root, "Rows").text = "0"
        if volume<0: 
            ET.SubElement(root, "Size").text = "0"
        else:
            ET.SubElement(root, "Size").text = str(volume*1.1)
        ET.SubElement(root, "SubstratePosition").text = position
        ET.SubElement(root, "SubstrateType").text = kind 
        ET.SubElement(root, "Type").text = t
        ET.SubElement(root, "ValveResource").text = vr
        ET.SubElement(root, "ValvePosition").text = vp
        ET.SubElement(root, "Units").text = u

        tree = ET.ElementTree(root)
        c = os.path.join(self.path,"chempart2.xml")
        with open(c, "wb") as f:
            tree.write(f, encoding="utf-8", xml_declaration=True)
    
    def add_chem(self,
                 source, 
                 chem="solvent", 
                 row=0, 
                 col=0, 
                 volume=-1, # if -1 indefinite volume
                 mode="factory setting|ADT" # dispense mode # adds a new chemical with a source
                 ): 
        
        if source in self.pt.plates:
            kind,position, rows, cols = self.pt.get(source)
            if row > rows or col > cols:
                print("\nERROR: %dx%d source %s for chemical %s cannot be in (%d,%d) cell" % (rows,cols,source,chem,row,col))
                sys.exit()
        else:
            kind, position = None, None  
            print("\nCAUTION: source %s for chemical %s is not in the plate list, assume off deck source" % (source,chem))           
            
        if chem == "solvent":
          color = self.rgb_to_uint(1,1,0) # yellow
        else:
          color = self.index2color(self.lib_count) 
        
        if chem: # chemical
              if self.verbose: 
                    print("adds <%s> to the library, sourced from <%s> (%d,%d)\nat <%s>, color=%d (%s)\n" % 
                                        (chem, kind, row, col, position, color, self.closest_color(color)))  
              self.ls.AddChemical(chem,color,self.units)
              if row==0 or col==0:
                  well = "off deck"
              else:
                  well = self.utils.tuple2well(row,col) 
              self.promptsfile.AddInitialSourceState(position,"None") # not covered   
        else: # library substrate
            chem = source
            well, row, col = "", 0, 0
            
        self.sources[chem] = (source, well) 
            
        self.AddSource(source,chem,kind,position,color,row,col,volume)
        self.chemfile.AddChemical(chem, mode) 
          
        self.lib_count+=1

    
    def rename_chem(self,old,new): # renames a chemical 
        status = self.ls.RenameChemical(old,new)
        self.HandleStatus(status)

    
    def dispense_chem(self, # dispenses chemical from a source & makes a source map
                      chem, # chemcial
                      add_to, # plate to add
                      range_str, # wells
                      volume, # volume
                      tag_code="1tip", 
                      opt=False, # adds to mapped chemicals for chemfile
                      layerIdx=-1  # if positive edits the map
                      ): 
        
        wells = self.utils.WellRangeFromString(range_str)
        values = self.utils.UniformValues(wells.Count, volume)
        tag  = self.to_tag(tag_code)
        i = layerIdx
        
        if layerIdx<0:
            status = self.ls.AddSourceMap(chem,
                            "Uniform", 
                             self.units, 
                             volume, 
                             wells, 
                             values, 
                             add_to, 
                             tag, 
                             self.map_count, 
                             1)
            i = self.map_count
        else:
            status = self.ls.EditSourceMap(chem,
                            "Uniform", 
                             self.units, 
                             volume, 
                             wells, 
                             values, 
                             add_to, 
                             tag, 
                             layerIdx, 
                             1)
                     
        self.HandleStatus(status)
        if self.verbose:
            print("sourced %d %s of %s :: %s, wells = %s :: %s" % 
                  (int(volume),self.units,chem,add_to,range_str,tag))
            
        if opt and layerIdx < 0: 
            self.chem[self.map_count] = (chem,) + self.sources[chem] + (add_to, range_str, volume)
            
        if layerIdx<0: self.map_count+=1
        
        return i
    
    def single_well_transfer(self, # single cell transfer between the substrates   
                             add_from, # substrate
                             add_to, # substrate
                             well_from, # well
                             well_to, # well
                             volume, # volume
                             tag_code="1tip", 
                             layerIdx = -1
                             ): 
        
        if add_from not in self.sources: 
            self.add_chem(add_from,None) # add substrate to sources   
            
        p_from = self.utils.well2point(well_from)
        p_to = self.utils.well2point(well_to)
        values = self.utils.UniformValues(1, volume)
        i = layerIdx
        
        if layerIdx<0: # new map
            status  = self.ls.AddArrayMap(add_from,
                            add_to,
                           "Uniform", 
                           self.units,
                           p_from, 
                           p_from,
                           p_to,
                           p_to,
                           volume,
                           values,
                           self.to_tag(tag_code), 
                           self.map_count
                          )
            i = self.map_count
        else: # edit the existing map
            status  = self.ls.EditArrayMap(add_from,
                            add_to,
                           "Uniform", 
                           self.units,
                           p_from, 
                           p_from,
                           p_to,
                           p_to,
                           volume,
                           values,
                           self.to_tag(tag_code), 
                           layerIdx,
                           1
                          )
                            
        self.HandleStatus(status)
        if layerIdx<0: self.map_count+=1
        
        return i
    
    def Pause(self, plate, text = ""): # sets pause with message
        self.pause_codebook[self.map_count]=text
        wells =  self.utils.WellRangeFromString("A1")
        values = self.utils.UniformObjects(1,text) 
        
        status = self.ls.AddParameterMap("Pause",
                                "Uniform",
                                "",
                                self.map_count, # due to bug in the program can only use digits, use pause_codebook
                                wells,
                                values,
                                plate,
                                "Processing",
                                self.map_count,
                                1
                                )        
        self.HandleStatus(status)
        self.map_count+=1
       
        
    def Delay(self, plate, t): # sets delay time in min
        wells = self.utils.WellRangeFromString("A1")
        values = self.utils.UniformObjects(1,t)
        
        status = self.ls.AddParameterMap("Delay",
                                "Uniform",
                                "min",
                                float(t),
                                wells,
                                values,
                                plate,
                                "Processing",
                                self.map_count,
                                1
                                )   
        
        self.HandleStatus(status)
        self.map_count+=1
        
    def Stir(self, plate, rate): # sets delay time in min
        wells = self.utils.WellRangeFromString("A1")
        values = self.utils.UniformObjects(1,rate)
        status = self.ls.AddParameterMap("StirRate",
                                "Uniform",
                                "rpm",
                                float(rate),
                                wells,
                                values,
                                plate,
                                "Processing",
                                self.map_count,
                                1
                                )        
        self.HandleStatus(status)
        self.map_count+=1
        if self.verbose:
           print("set stirring rate for %s at %g rpm" % (plate,rate))   
           
    def dummy_fill(self, plate, volume=50000): # skipped dummy fill with backsolvent
        if plate in self.pt.plates:
            full = self.tm.full_range(self.pt, plate)
            self.dispense_chem("solvent", # backsolvent
                      plate,  # substrate               
                      full, # the entire plate
                      volume, # added fake volume
                      "skip" # skip dispensing
                      )
        
    def modify_tag_code(self,code,letter): # add a letter coded option to the tag code
         if '_' in code:
            base, key = code.split('_')
            if letter not in key:
                key += letter
            return '%s_%s' % (base,key)
         else:
            return '%s_%s' % (code,letter)
    
        
    def transfer_replace_well(self, # add chaser, aliquot, replace it with solvent & delay
                              add_from, 
                              add_to, 
                              well_from, 
                              well_to, 
                              volume,           # added volume
                              chaser,           # added chaser (backsolvent) volume, can be zero
                              tag_code="1tip", 
                              delay=10., # delay in min after addition, can be zero
                              layerIdx = -1): 
        if layerIdx>=0:
           return self.edit_replace_well(add_from, add_to, well_from, well_to, volume, chaser, tag_code, layerIdx) 
        
        tag = self.to_tag(tag_code)
        if self.verbose:
            print("\nmap %d :: adds chaser, aliqots, replaces solvent and waits %g min" % (self.map_count,delay))
        if chaser>0: 
            self.dispense_chem("solvent" ,add_from, well_from, chaser, "chaser_S")
        i = self.single_well_transfer(add_from, add_to, well_from, well_to, volume, tag_code)
        self.dispense_chem("solvent", add_from, well_from, volume, self.modify_tag_code(tag_code,"S"))
        if self.verbose:
            print("transfers %d %s from %s, well = %s -> %s, well = %s :: %s" % 
                  (int(volume), self.units, add_from, well_from, add_to, well_to, tag))
        if delay>0: # delay time in min
            self.Delay(add_to, delay)
        return i

          
    def edit_replace_well(self, # add chaser, aliquot, replace it with solvent & delay
                          add_from, 
                          add_to, 
                          well_from, 
                          well_to, 
                          volume, 
                          chaser, 
                          tag_code="1tip", 
                          layerIdx = -1
                          ): 
        
        tag = self.to_tag(tag_code)
        if self.verbose:
            print("\nedited map %d :: adds chaser, aliqots, replaces solvent" % (layerIdx))
        if chaser>0: 
            self.dispense_chem("solvent" ,add_to, well_to, chaser, "chaser_S",False,layerIdx-1)
        self.single_well_transfer(add_from, add_to, well_from, well_to, volume, tag_code,layerIdx)
        self.dispense_chem("solvent", add_from, well_from, volume, self.modify_tag_code(tag_code,"S"),False,layerIdx+1)
        if self.verbose>0:
            print("transfers %d %s from %s, well = %s -> %s, well = %s :: %s" % 
                  (int(volume), self.units, add_from, well_from, add_to, well_to, tag))
        return layerIdx
        
    def transfer_replace_mapping(self, volume, chaser, tag_code="1tip", d=10.0): # do the transfer sequence for the entire transfer map
          i=0 
          
          if 'volume' not in self.tm.df.columns:
               self.tm.df['volume'] = pd.NA
          if 'chaser' not in self.tm.df.columns:
               self.tm.df['chaser'] = pd.NA
          if 'map' not in self.tm.df.columns:
               self.tm.df['map'] = pd.NA
               
          for _, add_from, well_from, _, add_to, well_to, _ in self.tm.mapping:
              self.transfer_replace_well(add_from, add_to, well_from, well_to, volume, chaser, tag_code, d)
              self.tm.df.loc[i,'volume'] = volume
              self.tm.df.loc[i,'chaser'] = chaser
              self.tm.df.loc[i,'map'] = self.map_count
              i+=1
              
          if self.verbose:
              print("\nTRANSFER MAP %d\n%s\n" % (self.transfer,self.tm.df))
          self.tm.to_csv("transfer%d" % self.transfer,self.stamp) # save the numbered transfer map
          self.transfer+=1
          
    def from_db(self, lib_ID): # get the parameter list
        self.design = self.ls.GetDesignFromDatabase(lib_ID,False)
        self.ID = lib_ID
        if self.design: 
            if self.verbose:
                print("loaded LS library design %d without attachments" % lib_ID)   
                self.project = self.ls.GetProjectName()
                self.name = self.ls.GetLibraryDesign()
                print("project %s, design name %s" % (self.project,self.name))
                self.info_libs()
        else:
            print("ERROR: cannot open LS library design %d" % lib_ID)
            sys.exit()
            
    def add_param(self,pname, ptype, punit):
            from LS_API import Param
            p = Param()   
            p.Description=""
            p.Expression = ""
            p.Name = pname
            p.Type = ptype
            p.DefaultUnit = punit
            if ptype in self.PTYPES:            
                self.ls.AddParameter(p)                
            else:
                print("ERROR: incorrect parameter type")
                sys.exit()   
                
    def get_params(self): # get the parameter list
        ps = list(self.ls.GetParameters())
        if ps:
            print("\n%d parameters found" % len(ps))
            for p in ps:
                print("%s :: type = %s, default unit = %s" % (p.Name,p.Type,p.DefaultUnit))
        else: 
            print("no parameters found")
    
    def get_units_types(self): # get the list of unit types
         self.units_types = list(self.ls.GetAllUnits())
    
    def get_units(self): # get the list of units
         self.get_units_types()
         self.units_list = []
         for t in self.units_types:
            u = list(self.ls.GetUnits(t))
            self.units_list.append(u)
            print("type = %s -> unit = %s" % (t,u))
        
    def sources_df(self): # make a dataframe for the sourcing map
            if self.chem:
                self.sdf = pd.DataFrame.from_dict(self.chem, 
                                                  orient="index",
                                                  columns=[ "chemical",
                                                            "source",
                                                            "well_from",
                                                            "plate_to",
                                                            "wells_to",
                                                            "volume_to"]
                                                  )
                
                self.sdf.reset_index(inplace=True)
                self.sdf.rename(columns={'index': 'map'}, inplace=True)
                if self.verbose: 
                    print("\nSOURCING\n%s\n" % self.sdf)
            else:
                print("no sources dictionary to convert to a dataframe")
            
    def sources_csv(self): # convert sourcing dataframe to CSV file
            if len(self.sdf):
                self.sdf.to_csv("sourcing_%d_%s.csv" % 
                                (self.ID,self.stamp), index=False)
                if self.verbose: 
                    print("plate info is written to a time stamped .csv file")
            else:
                print("no dataframe to save in a .csv file")
                
    def to_db(self, isnew): # True - new ID, False - overwrite existing ID in the database
        return self.ls.SaveDesignToDatabase(isnew, True) # 
    
    def rename(self, name): 
        self.ls.SetDesignName(name)
        self.name = name
    
    def finish_lib(self, isnew):  # adds to database and uses library IDs to complete records    
        self.ID = self.to_db(isnew)
        if self.ID<0:
            self.HandleStatus(self.ID)
            print("\nCAUTION: fakes ID's to complete xml records for AS\n") 
            self.fake_lib(10)
        else:
            if self.verbose: 
                print("\nsaved library %s with ID = %d\n" % (self.name,self.ID)) 
            self.log_libs()
                                     
    def log_libs(self):  
            self.to_db(False)    
            from LS_API import Library
            libs = self.ls.GetLibraries()
            if libs:
                for lib in libs: 
                    ID = lib.ID
                    kind, position, _, _ = self.pt.get(lib.Name)
                    self.chemfile.AddLibrary(ID, 
                       lib.Name, 
                       lib.Rows, 
                       lib.Columns, 
                       kind, 
                       position
                       )           
                    self.promptsfile.AddInitialLibraryState(ID,"None") 
                    if self.verbose: 
                        print("added library %d :: %s, %dx%d :: color = %d (%s)" % 
                              (ID, lib.Name, lib.Rows, lib.Columns, lib.Color,self.closest_color(lib.Color))) 
                        
    def info_libs(self):         
            from LS_API import Library
            libs = self.ls.GetLibraries()
            if libs:
                for lib in libs: 
                    if self.verbose: 
                        print("library %d :: %s, %dx%d :: color = %d (%s)" % 
                              (lib.ID, lib.Name, lib.Rows, lib.Columns, lib.Color,self.closest_color(lib.Color))) 
            

    def fake_lib(self, fake_ID): # uses fake IDs  to complete records
        self.ID = fake_ID
        for plate in self.pt.plates:
            if "source" in plate: continue
            kind, position, rows, cols = self.pt.get(plate)
            self.chemfile.AddLibrary(fake_ID, 
                       plate, 
                       rows, 
                       cols, 
                       kind, 
                       position
                       )           
            self.promptsfile.AddInitialLibraryState(fake_ID,"None") 
            fake_ID+=1
        
    def finish(self): # finish design     
        self.finish_lib(True)  # adds to database with a new ID and completes records   
        self.ID_folder()
        self.pt.to_df()
        self.pt.to_csv(os.path.join(self.dir,"substrates_%d" % self.ID),self.stamp) # save the substrate map
        self.sources_df()
        self.sources_csv() # save the sourcing map   
        self.finish_files()
        self.to_file(os.path.join(self.dir,"%s_%d_%s.lsr" % (self.name,self.ID,self.stamp)))
        self.move_stamped_files()
        return self.ID
    
    def ID_folder(self):
        self.dir = os.path.join(self.path,str(self.ID))
        if not os.path.exists(self.dir):
            os.makedirs(self.dir)
    
    def move_stamped_files(self):
        for f in os.listdir(self.path):
            if self.stamp in f:
                shutil.move(f, self.dir)          
        
    def finish_iterative(self): # finish design, iterative calls
        self.ID = self.to_db(False) # overwrite
        if self.ID<0:
            self.HandleStatus(self.ID)
            print("\nERROR: cannot overwrite the current design into the database\n") 
            sys.exit()
        else:
            self.ID_folder()
            if self.verbose: 
                print("\nsaved edited design %s with ID = %d\n" % (self.name,self.ID)) 
            self.to_file(os.path.join(self.dir,"%s_%d_p%d.lsr" % (self.name,self.ID,self.transfer)))
        
    def finish_files(self): # write AS files
        self.prompts = os.path.join(self.dir,self.xml("prompts_%d" % self.ID))
        self.chem = os.path.join(self.dir,self.xml("chem_%d" % self.ID))
        self.chemfile.Write(self.chem) # save the AS chemical manager xml file
        self.promptsfile.Write(self.prompts) # save the AS prompt xml file
            
    def to_file(self, path): # save the current design to a file
        if self.ls.SaveDesignToFile(path):
            print("saved the current LS design to %s" % path)
        
    def from_file(self, path): # import a design from a file (cannot be loaded into a database)
        base_name = os.path.basename(path)
        name = os.path.splitext(base_name)[0]
        self.design = self.ls.SaveDesignToFile(path)
        status = self.ls.SetDesignName(name)
        self.HandleStatus(status)
        
    def as_execute(self): 
        self.as_prep()    # prepare AS SiLA client
        self.as_run()    # execution with AS SiLA client
        self.as_finish()    # stop the client
        
    def as_prep(self): # prepare for run
        self.as10 = CustomAS10(self.verbose)
        self.as10.FindOrStartAS()
        
    def as_run(self): # run the standard experiment, ignore pauses
        self.as10.run(self.ID, self.prompts, self.chem)
        if self.as10.pause_count:
            if self.verbose:
                print("Ignored the total of %d pauses" % self.as10.pause_count)
        
    def as_run_paused(self): # begin the standard experiment, stop on pauses
        code, info =  self.as10.run(self.ID, 
                      self.prompts, 
                      self.chem,
                      None, # tip file
                      True,  # until paused
                      False) # begin
        m = int(info)
        if m==0:
            if self.verbose:
                print("Normal termination")
                return info
        if m in self.pause_codebook:
            t = self.pause_codebook[m]
            if self.verbose:
                print("Prompt map=%d, text=%s" % (m,t))
                return t
        else:
            if self.verbose:
                print("Prompt map not in the code book")
                return None
    
    def as_run_resume(self): # resume the experiment 
        return self.as10.run(self.ID, # does not matter
                      self.prompts, # does not matter
                      self.chem, # does not matter
                      None, # tip file
                      True,  # until paused
                      True) # resume
    
    def as_finish(self): # stop SiLA client
        self.as10.CloseAS()

class CustomPlate: # plate class for plate manager
    
    def __init__(self, name,kind, position):
        self.name =name.strip()
        self.kind = kind.strip()
        self.position = position.strip()
        self.rows, self.cols = self.parse_kind()

    def __repr__(self):
        return "Plate = (name=%s, kind=%s, position=%s)" % (self.name,self.kind,self.position)
    
    def parse_kind(self): # guesses substrate dimensions from the name
        pattern = r'(\d+)x(\d+)'
        match = re.search(pattern, self.kind)
        if match:
            rows = int(match.group(1))
            cols = int(match.group(2))
            return rows, cols
        else:
            return 1,1


class CustomPlateManager: # plate manager
    
    def __init__(self):
        self.plates = {}
        self.df = pd.DataFrame()
        self.n_plates = 0
        self.verbose = CustomVerbosity()
        
        self.positions = [ # change when updated, any order
            'Deck 8-9 Position 1',
            'Deck 8-9 Position 3',
            'Deck 10-11 Position 2',
            'Deck 10-11 Position 3',
            'Deck 12-13 Heat-Cool-Stir 1',
            'Deck 12-13 Heat-Stir 2',
            'Deck 12-13 Heat-Stir 3',
            'Deck 14-15 Heat-Stir 1',
            'Deck 14-15 Heat-Stir 2',
            'Deck 14-15 Heat-Stir 3',
            'Deck 16-17 Waste 1',
            'Deck 16-17 Waste 2',
            'Deck 16-17 Waste 3',
            'Deck 19-20 Position 1',
            'Deck 19-20 Position 2',
            'Deck 19-20 Position 3',
            ]
        # rows x columns
        self.kinds = [ # change when updated, any order
            "Plate 1x1 Reservoir",
            "Rack 1x2 125mL Vial",
            "Rack 2x4 20mL Vial",
            "Rack 4x6 8mL Vial",
            "Rack 4x6 4mL Vial",
            "Rack 4x6 4mL Shell",
            "Rack 6x8 2mL Vial",
            "Rack Al 8x12 1mL Vial",
            "Rack 8x12 NanoIndentor",
            "Rack Al 8x12 1.2mL Vial",
            "Rack 8x12 1mL Vial",
            "Rack 8x12 1.2mL Vial",
            "Filter 8x12 Aspirate",
            "Filter 8x12 Dispense",
            "8x6 deep 48 well NEST",
            "4x6 deep 24 well NEST",
            "Rack VT54 6x9 2mL Septum Low",
            "Rack 12x5 ICP manual",
            "Rack 15x6 ICP manual",
            "Rack 5x12 ICP robotic",
            "Rack 6x15 ICP robotic",
            "Rack 8x3 NMR bin",
            "Rack 2x1 100mL Kaufmann H-cell",
            "Rack 3x4 six Kaufmann H-cells",
            "Rack 4x2 RedoxMe H-cell",
            ]


    def add(self, name, kind, position): # add a new plate, by convention all source plates have "source" in their names
        name = name.strip()
        kind = kind.strip()
        position = position.strip()
        
        if not self.kind_check(kind):
            print("substrate %s in not in substrate list, ignore" % kind)
            return 0
        
        if not self.pos_check(position):
            print("position %s in not in positions list, ignore" % position)
            return 0
            
        if name not in self.plates: 
            p = CustomPlate(name, kind, position)
            self.plates[name]=(kind, position, p.rows, p.cols)
            self.n_plates += 1
            return 1
        else:
            print("duplicative platename %s, ignore" % name)
            return 0
            
    def report(self):
        if self.verbose: 
            print("%d unique plates" % self.n_plates)            

    def get(self, name): # find plate record
        name = name.strip()
        if name in self.plates:
            return self.plates[name]
        else:
            print("plate %s is not in the plate list" % name)
            
    def to_df(self): # make a table of substrate records
        if self.plates:
            self.df = pd.DataFrame.from_dict(self.plates, orient="index",columns=["kind","position","rows","columns"])
            self.df.reset_index(inplace=True)
            self.df.rename(columns={'index': 'substrate'}, inplace=True)
            if self.verbose:
                print("\nSUBSTRATE MAP\n%s\n" % self.df)
        else:
            print("no plate dictionary to convert to a dataframe")
            
    def to_csv_stamped(self): # save time stamped substrate records to a CSV file
         now = datetime.now()
         stamp = now.strftime('%Y%m%d_%H%M%S')
         self.to_csv("plates",stamp)
        
    def to_csv(self, name, stamp): # save substrate records to a CSV plate
        if len(self.df):
            self.df.to_csv("%s_%s.csv" % (name,stamp), index=False)
            if self.verbose: 
                print("plate info is written to a time stamped .csv file")
        else:
            print("no dataframe to save in a .csv file")
            
    def pos_general(self, position): # checks that positions have the right structure
        position =position.strip()
        digits = re.findall(r'\d+', position)
        pos = int(digits[-1]) if digits else None
        
        if pos is None or pos > 3:
            print("invalid position number")
            return False     
        
        if "Deck" not in position:
             print("Deck is not given")
             return False
         
        return True
    
    def pos_check(self,position): # check the position against the list of allowed positions
        return position.strip() in self.positions
    
    def kind_check(self,kind):  # check the substrate against the list of allowed substrates
        return kind.strip() in self.kinds

class CustomTransferMap: # a class to create transfer maps
    
    def __init__(self):
        self.lib_from = []
        self.lib_to = []
        self.mapping = []
        self.df = pd.DataFrame()
        self.n_to = 0
        self.n_from = 0
        self.verbose = CustomVerbosity()
         
    def sort_labels(self,labels, direction): # sorting of wells
        def sort_key(label):
                row, col = label[0], int(label[1:])
                if direction: 
                    return (row, col)
                else:
                    return (col,row)
        return sorted(labels, key=sort_key)

    def generate_labels(self,range_str,direction):  # 0 by column, 1 by row
        range_str = range_str.strip()
        if ":" in range_str:
            start, end = range_str.split(":")
            start_row, start_col = start[0], int(start[1:])
            end_row, end_col = end[0], int(end[1:])
            rows = string.ascii_uppercase[string.ascii_uppercase.index(start_row):string.ascii_uppercase.index(end_row) + 1]
            columns = range(start_col, end_col + 1)
            if direction:
                labels = ["%s%d" % (row,col) for row in rows for col in columns]
            else:
                labels = ["%s%d" % (row,col) for col in columns for row in rows ]
            return labels
        else:
            return [range_str]
        
    def well2tuple(self, well): # same as in utils
        letter = well[0].upper()
        col = int(well[1:])
        row = ord(letter) - ord('A') + 1
        return (row,col)
    
    def tuple2well(self, row, col): # same as in utils
        return "%s%d" % (chr(64 + row),col)
    
    def well2native(self, pt, plate, well):
        if plate in pt.plates:
            kind, _, rows, cols = pt.get(plate)
            row, col = self.well2tuple(well)
            if "NMR" in kind:
                if rows < cols:
                    return str((row-1)*cols + col)
                else:
                    return str(rows*(cols-col) + row)
            if "ICP" in kind:
                if rows > cols:
                    return self.tuple2well(col, row)
                else:
                    return self.tuple2well(1+rows-row, col)
        return well    
    
    def check_well(self,well,n_rows,n_cols): # check that the cell can be on the substrate
        row, col = self.well2tuple(well)
        if row>n_rows or col>n_cols:
            return False
        else:
            return True

    def generate_combined_labels(self, pt, plate, ranges_str, direction): # combines and orders well ranges 
        if "full" in ranges_str:
            ranges_str = self.full_range(pt, plate)
        range_list = ranges_str.split(',')
        combined = []
        for range_str in range_list:
            labels = self.generate_labels(range_str,direction)
            for label in labels: 
                if label not in combined: 
                    combined.append(label)  
        combined = self.sort_labels(combined, direction)
        record = []
        if plate not in pt.plates:
            print("\n>>> CAUTION: plate %s is not in the list of plates, ignore\n" % plate)
        else:
            _, _, rows, cols = pt.get(plate)
            if self.verbose: 
                print("%s wells (%s, %dx%d plate) = %s" % (len(combined),plate,rows,cols,combined))
            flag=0
            for well in combined:   
                if self.check_well(well,rows,cols):
                    record.append((plate,well,self.well2native(pt, plate, well)))
                else:
                    flag=1
            if flag:
                print("\n>>> CAUTION: plate %s dimensions exceeded, only valid wells added\n" % plate)
            
        return record
    
    def check_unique(self, list): # removes duplicates
        unique=[]
        for item in list:
            if item not in unique:
                unique.append(item)
        return unique
    
    def shuffle(self, list):  # random shuffle with a checks that the first well is not the same as the previous last well   
        last = list[-1]
        u = list[:]
        while True:
            random.shuffle(u)
            if u[0] != last:
                break   
        return u
    
    def full_range(self, pt, plate): #  full plate
        _, _, rows, cols = pt.get(plate)
        return "A1:%s" % self.tuple2well(rows,cols)

    def full_plate(self, pt, plate, direction): # 0 by column, 1 by row # a list of wells in the full plate
        range_str =  self.full_range(pt, plate)
        return self.generate_labels(range_str,direction)
    
    def add_from(self,pt,plate,reagent_str,direction): # 0 by column, 1 by row # a list of sampled wells
        self.lib_from += self.generate_combined_labels(pt,plate,reagent_str,direction)
        self.n_from=len(self.lib_from)
        
    def add_to(self,pt,plate,reagent_str,direction): # 0 by column, 1 by row # a list of destination wells
        self.lib_to +=self.generate_combined_labels(pt,plate,reagent_str,direction) 
        self.n_to=len(self.lib_to)
               
    def report_from(self): # reporting 
        if self.verbose: 
            print("the total of %d wells to map from" % self.n_from)
        
    def report_to(self): # reporting 
        if self.verbose:           
            print("the total of %d wells to map to" % self.n_to)
        
    def map(self,randomize): # optional randomization on each repeat - making a transfer map
        if self.n_from == 0 or self.n_to == 0:
            return 0        
        q, m = 1, 0
        self.mapping=[]
        while(q):
                u = self.lib_from[:]
                if randomize:  u = self.shuffle(u)
                for i in range(self.n_from):
                    self.mapping.append((m+1,)+u[i]+self.lib_to[m])
                    m+=1
                    if m==self.n_to:
                        q=0
                        break                    
        if self.verbose: 
            print("\n%d full repeats" % math.floor(self.n_to/self.n_from))
        return 1
        
    def to_df(self): # converting the transfer map to a dataframe table
        if self.mapping:
            self.df = pd.DataFrame(self.mapping, columns=['index', "plate from",'well from',"native_from","plate to","well to","native to"])
            if self.verbose: 
                print("\nTRANSFER MAP\n%s\n" % self.df)
        else:
            print("no mapping to convert to a dataframe")
            
    def to_csv_stamped(self): # saving the transfer map to a datetime stamped CSV file
        now = datetime.now()
        stamp = now.strftime('%Y%m%d_%H%M%S')
        self.to_csv("mapping",stamp)
        
    def to_csv(self, name, stamp):  # saving the Nan trimmed transfer map to a CSV file
 
        if len(self.df):
                self.df.to_csv("%s_%s.csv" % (name,stamp), index=False)
                if self.verbose:                     
                    print("mapping is written to a time stamped .csv file\n")
        else:
            print("no dataframe to save in a .csv file")
            
##################################################### TESTS ##############################################################

def basics_test():  # a test of basic plate and transfer map methods
     
        pt = CustomPlateManager()
        tm = CustomTransferMap()  
        
        pt.add("plate1","Rack 3x4 six Kaufmann H-cells","Deck 12-13 Heat-Cool-Stir 1")
        pt.add("ICP1","Rack 5x12 ICP robotic","Deck 16-17 Waste 1")
        pt.add("ICP2","Rack 5x12 ICP robotic","Deck 16-17 Waste 1")           
              
        print("\n ==== map from ==== ")
        tm.add_from(pt,"plate1","A2:C2,A4:C4",0) # by column
        tm.report_from()
         
        print("\n ==== map to ==== ")
        tm.add_to(pt,"ICP1","full",1) # 60 tube rack,  1 by row
        tm.add_to(pt,"ICP2","full",1) # 60 tube rack,  1 by row
        # tm.add_to(pt,"ICP1","full",1) # 90 tube rack,  1 by row
        # tm.add_from("NMR1","full",1)  1 by row
        # tm.add_from("NMR2","full",1)  1 by row
        tm.report_to()
        
        tm.map(1)   # no randomization of sampling     
        tm.to_df()
        tm.to_csv_stamped()
    
            
def LS_test(): # a test of LS functions - a cyclical walk through plate1 mapping it on ICP1 rack
    
    ld = CustomLS10()
    ld.create_lib("test")
    
    ld.add_param("Delay","Time","min")
    ld.add_param("StirRate","Stir Rate","rpm")
    ld.add_param("Pause","Text","")
    ld.get_params() 
    
    #print(self.units_list())
    #ld.test_van_der_corput()
    
    # making a substrate library
    ld.pt.add("source1","Rack 2x4 20mL Vial","Deck 10-11 Position 2")
    ld.pt.add("plate1","Rack 3x4 six Kaufmann H-cells","Deck 12-13 Heat-Cool-Stir 1")
    ld.pt.add("plate2","Rack 3x4 six Kaufmann H-cells","Deck 14-15 Heat-Stir 1")  # to stir all six cells
    ld.pt.add("ICP1","Rack 5x12 ICP robotic","Deck 16-17 Waste 1")    
    #ld.pt.add("ICP1","Rack 12x5 ICP manual","Deck 16-17 Waste 1") 
    #ld.pt.add("NMR1","Rack 8x3 NMR bin","Deck 16-17 Waste 1") 
    #ld.pt.add("NMR2","Rack 8x3 NMR bin","Deck 16-17 Waste 2")  
    
    # adding all plates 
    ld.add_all_plates()
    
    # adding off deck and plate sources
    ld.add_chem(None,"solvent")
    
    # making the transfer map
    if ld.verbose: print("\n ==== map from ==== ")
    ld.tm.add_from(ld.pt,"plate1","A1:C1",0) # by column  red compartments
    ld.tm.report_from()
   
    if ld.verbose: print("\n ==== map to ==== ")
    ld.tm.add_to(ld.pt,"ICP1","full",1) # 60 tube rack,  1 by row
    #ld.tm.add_to(ld.pt,"NMR1","full",0) # 1 by row
    #ld.tm.add_to(ld.pt,"NMR2","full",0) # 1 by row
    ld.tm.report_to()
    
    ld.tm.map(0)   # no randomization of sampling     
    ld.tm.to_df()
    
    ld.Stir("plate1", 500) # rpm
    ld.Stir("plate2", 500) # rpm
    ld.dummy_fill("plate1")
    ld.dummy_fill("plate2")
    
    ld.Pause("plate1", "prep finished") # message
    
    # sourcing and dispensing chemicals
    
    source = ld.tm.full_plate(ld.pt, "source1", 1)
    
    for i in range(ld.tm.n_from):   
        r, c = ld.tm.well2tuple(source[i])
        ld.add_chem("source1",
                    "mixture%d" % (i+1),
                    r, # row
                    c, # col
                    volume = 5000 # uL
                    ) 
    
    for i in range(ld.tm.n_from):   
        j = i+1
        plate, well, _ = ld.tm.lib_from[i]
        row, col = ld.tm.well2tuple(well)
        
        well = ld.tm.tuple2well(row,col+2)  # into green compartments
        ld.dispense_chem("mixture%d" % j,
                         plate,
                         well,
                         1000, # added volume
                         "1tip",
                         True # add to sourcing log
                         )
    
    ld.Pause("plate1", "mixtures in green compartments A3:C4") # message
    
    # transferring using the transfer map
    ld.transfer_replace_mapping(200, # volume
                                2000, # chaser volume
                                "1tip",
                                0.01 # min
                                ) 
    
    ld.Pause("plate1", "stirring off") # message
    
    ld.Stir("plate1", 0) # rpm
    ld.Stir("plate2", 0) # rpm
   
    ld.finish()       # writing into the database and creating log files and xml files for AS  
    #sys.exit()
    
    ld.as_prep()    # run the standard experiment    
    ld.as_run_paused()
    print("\n\n********************  CONTROL BACK *******************************\n\n")
    ld.as_run_resume()
    ld.as_finish()

def LS_iterative(): # a test of LS functions - a cyclical walk through plate1 mapping it on ICP1 rack

    ld = CustomLS10()     
    ld.as_prep()
        
    ld.create_lib("test_simple")    
    ld.add_param("Delay","Time","min")
    ld.add_param("StirRate","Stir Rate","rpm")
    ld.get_params() 
    
    ld.pt.add("plate1","Rack 3x4 six Kaufmann H-cells","Deck 12-13 Heat-Cool-Stir 1")
    ld.pt.add("ICP1","Rack 5x12 ICP robotic","Deck 16-17 Waste 1") 
   
    # making the transfer map
    if ld.verbose: print("\n ==== map from ==== ")
    ld.tm.add_from(ld.pt,"plate1","A1:C2",0) # by column
    ld.tm.report_from()
   
    if ld.verbose: print("\n ==== map to ==== ")
    ld.tm.add_to(ld.pt,"ICP1","full",0) # 60 tube rack,  1 by row
    ld.tm.df['volume'] = pd.NA
    ld.tm.df['chaser'] = pd.NA
    ld.tm.df['stamp'] = ""
    ld.tm.df['stamp'] = ld.tm.df['stamp'].astype(str)
   
    ld.tm.report_to()
    
    ld.tm.map(0)   # no randomization of sampling     
    ld.tm.to_df()
    
    ld.add_all_plates()
    ld.Stir("plate1",500) # rpm
    
    ld.add_chem(None,"solvent") 
    ld.add_chem("plate1",None)  
    ld.dummy_fill("plate1")
    
    ID = ld.finish()
    promptsfile = ld.prompts
    chemfile = ld.chem
   
    i, t = 0, -1
    volume = 200 # uL
    chaser = 2000 # uL
    
    for _, add_from, well_from, _, add_to, well_to, _ in ld.tm.mapping: 
        
        print("\n********************** step %d **************************\n" % (i+1))
        ld.from_db(ID)
        ld.transfer = i+1

        t = ld.transfer_replace_well(add_from, 
                                  add_to, 
                                  well_from, 
                                  well_to, 
                                  volume, 
                                  chaser, 
                                  "1tip", 
                                  0., # delay time, min
                                  t)
        
        print("\n********************* STEP %d ***************************\n" % ld.transfer)
         
        ld.tm.df.loc[i,'volume'] = volume
        ld.tm.df.loc[i,'chaser'] = chaser
        ld.finish_iterative()  
        
        now = datetime.now()
        ld.tm.df.loc[i,'stamp'] = now.strftime('%m-%d-%Y %H:%M:%S')
        
        try: 
            ld.as_run()
            ld.as_finish()
        except:
            break       
        
        i+=1
      
    if i: 
        self.df = self.df.loc[:i]
        print("\nTIME STAMPED TRANSFER MAP\n%s\n" % (ld.tm.df))    
        ld.tm.to_csv("transfer_log",ld.stamp) # save the transfer map
       
    
#LS_test() # running the test

def LS_once(): # a test of LS functions - a cyclical walk through plate1 mapping it on ICP1 rack

    ld = CustomLS10()     
        
    ld.create_lib("test_simple")    
    ld.add_param("Delay","Time","min")
    ld.add_param("StirRate","Stir Rate","rpm")
    ld.get_params() 
    
    ld.pt.add("plate1","Rack 3x4 six Kaufmann H-cells","Deck 12-13 Heat-Cool-Stir 1")
    ld.pt.add("ICP1","Rack 5x12 ICP robotic","Deck 16-17 Waste 1") 
   
    # making the transfer map
    if ld.verbose: print("\n ==== map from ==== ")
    #ld.tm.add_from(ld.pt,"plate1","A1:C2",0) # by column
    ld.tm.add_from(ld.pt,"plate1","A1",0) # by column
    ld.tm.report_from()
   
    if ld.verbose: print("\n ==== map to ==== ")
    #ld.tm.add_to(ld.pt,"ICP1","full",0) # 60 tube rack,  1 by row
    ld.tm.add_to(ld.pt,"ICP1","A1",0) # 60 tube rack,  1 by row
    ld.tm.df['volume'] = pd.NA
    ld.tm.df['chaser'] = pd.NA
    ld.tm.df['stamp'] = ""
   
    ld.tm.report_to()
    
    ld.tm.map(0)   # no randomization of sampling     
    ld.tm.to_df()
    
    ld.add_all_plates()
    ld.Stir("plate1", 500) # rpm   
    ld.add_chem(None,"solvent") 
    ld.add_chem("plate1",None)  
    ld.dummy_fill("plate1")
   
    i=0
    volume = 200 # uL
    chaser = 0 # uL
    
    for _, add_from, well_from, _, add_to, well_to, _ in ld.tm.mapping: 

        ld.transfer_replace_well(add_from, 
                                  add_to, 
                                  well_from, 
                                  well_to, 
                                  volume, 
                                  chaser, 
                                  "1tip", 
                                  0., # delay time, min
                                   )
         
        ld.tm.df.loc[i,'volume'] = volume
        ld.tm.df.loc[i,'chaser'] = chaser
               
        i+=1
      
    ID = ld.finish()
    
    ld.as_execute()
    
#LS_test() # running the test        

LS_once()     