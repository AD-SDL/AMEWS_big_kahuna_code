from re import M
import sys, os, json, time, shutil
import sila2.client 
from sila2.framework.errors.sila_connection_error import SilaConnectionError

class CustomAS10: # v is verbosity
		
	def __init__(self, verbosity):
		self.verbose = verbosity
		self.stopped = "Stopped"
		self.running = "Running"
		self.paused = "Paused"
		self.pause_count = 0
		self.no_tips = "OutOfTips"
		self.active_prompt = "ActivePrompt"
		self.wait = "Timeout"		
		self.error = "Error"
		self.timeout = 5 # sec
		self.ID = 0
		self.client = None
		self.es =  None
		self.state = None
		self.next = None
		self.last = None
		self.final = None
		self.status = None
		self.active = None
		self.active_content = None
		self.info = None
		self.title = None
		self.prompt = None
		# logging
		self.logs_dir = "C:\Automation Studio\Logs"
		self.logs = None
		self.log = None
		
	def list_logs(self):
		 return set(os.listdir(self.logs_dir))
	
	def get_log(self, state):
		if state == 0:
			self.logs = self.list_logs()
			self.log = None
		else:
			self.logs = self.list_logs() - self.logs
			for log in self.logs:
				if log.startswith("ASMain_") and log.endswith(".log"):
					self.log = log
					if self.verbose:
						print("found log file %s" % log)
	
	def copy_log(self, folder):
		copy_from = os.path.join(self.logs_dir,self.log)
		copy_to = os.path.join(folder,self.log)
		shutil.copy2(copy_from,copy_to)
	
	def checkResult(self, response):
		status = response['StatusCode']
		if status < 0:
			print("ERROR: %s" % response)
		
	def discover(self, name):
		try: 
		    self.client = sila2.client.SilaClient.discover(server_name=name,
                                                 insecure=True,
                                                 timeout=self.timeout)
		    if self.verbose:
		        print("\nSILA client for server <%s> opened at %s, port = %d" % 
					(name, self.client.address, self.client.port))
		except Exception as e:
		    print(f"Error: {e}")
		
	def StartAS(self):
		self.discover("AutomationRemote")
		if self.client:
		    response = self.client.AutomationStudioRemote.Start()
		    return json.loads(response.ReturnValue)
		else:
		    print("ERROR: cannot find SILA server, abort") 
		    sys.exit()
	
	def FindOrStartAS(self):
		start = self.StartAS()
		self.checkResult(start)
	
		if start['StatusCode'] == 0: time.sleep(20)  
		
		self.discover("AutomationStudio")
		self.es = self.client.ExperimentService
	
	def CloseAS(self):
		self.discover("AutomationStudio")
		try:
			self.checkResult(json.loads(self.client.AutomationStudio.Shutdown().ReturnValue))
			if self.verbose:
				print("\nSILA client %s closed" % self.client)
		except SilaConnectionError:
			pass    
	
	def RunAS(self, design_id, promptsfile, chemfile, tipfile):
		self.state = self.GetState()
		if  self.state != self.stopped:
			print("CAUTION: AS10 not ready to run")
			sys.exit()
		self.checkResult(json.loads(self.es.ChooseDesignID(design_id).ReturnValue))
		self.checkResult(json.loads(self.es.SetPrompts(promptsfile).ReturnValue))
		self.checkResult(json.loads(self.es.SetChemicalManager(chemfile).ReturnValue))
		if tipfile is not None:
			self.checkResult(json.loads(self.es.SetTipManagement(tipfile).ReturnValue))
	
		self.checkResult(json.loads(self.client.RunService.Start().ReturnValue))
		
		return self.WaitNextState(self.stopped, 120) # 2 min wait to start
	
	def GetStatusContent(self):
		response = json.loads(self.client.ExperimentStatusService.GetStatus().ReturnValue)
		# print("\nresponse = %s" % response)
		return response['Content']
		
	def GetState(self):
		
		self.active = None
		self.active_content = None
		self.info = None
		self.title = None
		
		self.status = self.GetStatusContent()
		if self.status == 'Experiment running':
			
			self.active = json.loads(self.client.ExperimentStatusService.GetActivePrompt().ReturnValue)
			#print("ACTIVE = %s" % self.active)
			
			if self.active['StatusCode'] == 0:				
				self.active_content = json.loads(self.active['Content'])
				if 'InformationMessage' in self.active_content:
						self.info = self.active_content['InformationMessage']
				if 'Title' in self.active_content:
						self.title = self.active_content['Title']
				if self.info.startswith('No more tips'):
					return self.no_tips
				else:
					return self.active_prompt
			elif self.active['StatusCode'] == 1:
				return self.running
			
		elif self.status == 'Experiment completed':
			return self.stopped
		elif self.status == 'No experiment running':
			return self.stopped
		elif self.status == 'Experiment paused':
			return self.paused
		elif self.status == 'Experiment aborted':
			return self.stopped
		elif self.status == 'Experiment error':
			return self.error
		else:
			raise Exception("ERROR: Unexpected state, status = %s" % self.status)
		
	def WaitNextState(self, expected, dt):
		t = time.monotonic() + dt

		self.state = self.GetState()
		if self.state != expected:
			return self.state
		
		while time.monotonic() <= t:
			time.sleep(1)
			self.state = self.GetState()
			if self.state != expected:
				return self.state
			
		return self.wait

	def GetActivePrompt(self):
		self.active = json.loads(self.client.ExperimentStatusService.GetStatus().ReturnValue)
		if self.active['StatusCode'] == 0:
			if self.active['Content']:
				try: 
					return json.loads(self.active['Content'])
				except: 
					return None
		return None

	def GetActivePromptMessage(self, m):
		if m: 
			if 'InformationMessage' in m:
				return m['InformationMessage']
			elif 'value' in m:
				return m['value']	
			raise Exception("ERROR: Unexpected active prompt content format")
		return None
	
	def run(self, 
		 design_ID, # design ID
		 promptsfile, # prompts file w intial states
		 chemfile, # chem manager file
		 tipfile = None, # tip file if used
		 pause = False,  # stop and report text message when pause encountered
		 resume = False # resume after pause
		 ):

		flag=0
				
		if resume:
			if self.verbose: 
				print("\n>> Run of design %d continues after Pause %d" % 
						(self.ID,self.pause_count))
			self.client.ExperimentStatusService.SetInput("OK")
			self.last = self.GetState()  
		else:
			self.get_log(0)
			self.pause_count = 0
			self.ID = design_ID
			if self.verbose: 
				print("\n>> Run of design %d started" % design_ID)
				if tipfile:
					print("Tip file = %s" % tipfile)
				print("Chemical manager file = %s" % chemfile)
				print("AS prompt file = %s\n" % promptsfile)				
				self.last =self.RunAS(design_ID, promptsfile, chemfile, tipfile)  		
				
		while True:
			self.next = self.WaitNextState(self.last, 1)
        
			if self.next != self.wait:
				self.last = self.next
            
				if self.last == self.no_tips:
					print("ERROR: The instrument is out of tips")
					
				elif self.last == self.active_prompt:
					print("CAUTION: AS10 prompt <%s> needs input: %s" % (self.title,self.info))
					
					selector = self.title.lower()
					
					if "paused" in selector: 
						self.pause_count += 1
						if self.verbose:
							print("Pause %d, prompt=%s" % 
								(self.pause_count, self.info))
						if pause: 
							return self.pause_count, self.info.split('.')[0]
						else:
							self.client.ExperimentStatusService.SetInput("OK")
							
					if "reset"	in selector:
						pass #self.client.ExperimentStatusService.SetInput("No")					

				elif self.last == self.paused:
					print("CAUTION: User paused experiment")	
					
				elif self.last == self.running:
					print("ALERT: The experiment has resumed")
					
				elif self.last == self.stopped:
					flag=1
					break
					
		self.final = self.GetStatusContent()
		if self.final == "Experiment completed":
			if self.verbose: 
				print("FINAL: The experiment has completed")
			self.get_log(1)
			self.copy_log(os.path.dirname(chemfile))			
			return self.pause_count, "finished"
		elif self.final == "Experiment aborted":
			print("FINAL: The experiment was aborted")
			return self.pause_count, "aborted"
		else:
			print("FINAL: Unexpected final status: %s" % self.final)
		
		return self.pause_count, self.final
			
		
			



