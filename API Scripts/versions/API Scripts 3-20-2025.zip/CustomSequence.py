
import sys, os
import string, math
import json, time, shutil, glob
from datetime import datetime
import numpy as np
import pandas as pd
import tkinter as tk
from tkinter import filedialog

user = os.getlogin()
sys.path.append('C:/Users/%s/Dropbox/Instruments cloud/Robotics/Unchained BK/AS Scripts/API Scripts' % user)

from CustomService import *


#######################################################################################################################

class CustomSequence:

    def __init__(self, run = None):

        self.exp = None
        self.c0 = {}
        self.log = None
        self.t0 = {}
        self.user = os.getlogin()
        self.exp_path = r"C:\Users\%s\Dropbox\Instruments cloud\Robotics\RESULTS" % self.user

        if run: 
            self.run = run
            self.exp = run.exp
            print("\n>> Experiment folder = %s" % self.exp)
            self.results = os.path.join(self.exp, "Results")
        print(">> Results folder = %s" % self.results)
        os.makedirs(self.results, exist_ok=True)

# ====================================== consolidate log files  ===============================================


    def select_dir(self): # select directory by cursor

        root = tk.Tk()
        root.withdraw()  # Hide the root window
        self.exp = filedialog.askdirectory(initialdir=self.exp_path, 
                                           title="Select an experiment")

        print("\n>> Experiment folder = %s" % self.exp)
        self.results = os.path.join(self.exp, "Results")
        print(">> Results folder = %s" % self.results)
        os.makedirs(self.results, exist_ok=True)

        try:
            if self.exp: 
                self.consolidate_records()
        except Exception as e:
           print(">> Cannot consolidate digests, error = %s" % e)

    def consolidate_records(self): # consolidate all records

            self.consolidate_waste_logs()
            self.combine_AS_digests()
            self.add_ICP_records()

    def consolidate_waste_logs(self):  # consolidate waste logs and remove individual logs

        files = glob(os.path.join(self.exp, "waste*.csv"))
        dfs = []
        for f in files:
            ID = f.replace('.csv', '').split('_')[-1]
            try:
                df = pd.read_csv(f)
                df.insert(0, "library", int(ID))
                print(">> Processing waste from library %s" % ID)
                df = df[~df['container'].str.contains('glass', case=False, na=False)]
                if len(df): dfs.append(df)
                os.remove(f)
            except: pass

        if len(dfs):
            waste = pd.concat(dfs, ignore_index=True)
            waste = waste.sort_values(by="library", ascending=True)
            waste = waste.drop(columns=['Unnamed: 0'])
            f = os.path.join(self.exp,"waste_ICP_combined.csv")
            waste.to_csv(f, index=False)


    def find_rack(self, j): # look at the rows below for a rack container
        for i in range(j, len(self.last_digest)):
            if "rack" in self.last_digest.loc[i, "category"]:
                return self.last_digest.loc[i, 'container']
        return self.last_digest.loc[j, 'container']

    def correct_auxiliary(self): # put rack container into blanks, fills, and calibrations
        for i, r  in self.last_digest.iterrows():
            if "rack" not in r["category"]:
                self.last_digest.loc[i, "container"] = self.find_rack(i)

    def combine_AS_digests(self):

        self.last_digest = None
        self.log = None
        self.t0 = {}
        self.c0 = {}
        self.fill = "fill1"

        try: 
            self.log = pd.read_csv(os.path.join(self.exp, "AS_sequence_log.csv"))
        except:
            print(">> Cannot find sequence log file, abort")
            return 0

        print("\n\n>> Using AS_sequence_log.csv file to consolidate AS digests\n")
        self.log['AS log'] = self.log['AS log'].fillna("")

        j=-1

        dfs = []
        for i, r in self.log.iterrows():
            ID = r["ID"]
            category = r["category"]
            container = r["container"]
            barcode = r["barcode"]
            f = r["AS log"]
            if f:
                f = f.replace("ASMain","ASDigest_vols")
                f = f.replace(".log",".csv")
                g = os.path.join(self.exp, f)
                df = pd.read_csv(g)
                if "fill" in category:
                    if category != self.fill:
                        self.fill = category
                    f = "Active_%s.json" % container
                    g = os.path.join(self.exp, f)
                    if os.path.exists(g): 
                        with open(g, 'r') as j:
                            u = json.load(j)
                            self.c0[category] = u["creator"]["content"].copy()
                            print(">> Found %s content json file %s" % (category,f))

                if len(df):
                    print(">> Processing %s : ID=%d, container=%s, barcode=%s, category=%s" % (f, ID, container, barcode, category))
                    df.insert(0, "library", ID)
                    df.insert(1, "container", container)
                    df.insert(2, "barcode", barcode)
                    df.insert(3, "category", category)
                    df.insert(4, "feed", self.fill)
                    dfs.append(df)

        if len(dfs):
            self.last_digest = pd.concat(dfs, ignore_index=True)
            self.correct_auxiliary()
            self.last_digest['sample'] = self.last_digest['container'] + '-BK-' + self.last_digest['well to']
            self.last_digest.insert(0, 'sample', self.last_digest.pop('sample'))

            for i, r in self.last_digest.iterrows(): # zero times from the first fill

                if "fill" in r['category']:
                    dt = datetime.strptime(r["datetime"], "%m/%d/%Y %H:%M:%S")
                    c = self.run.counter2cell(r["well to"])
                    self.last_digest.loc[i, 'sample'] = None
                    self.last_digest.loc[i, 'container'] = None
                    self.last_digest.loc[i, 'plate from'] = r["plate to"]
                    self.last_digest.loc[i, 'well from'] = c
                    self.last_digest.loc[i, 'plate to'] = None
                    self.last_digest.loc[i, 'well to'] = None
                    self.last_digest.loc[i, 'volume'] = np.nan
                    self.last_digest.loc[i, 'chaser'] = np.nan
                    self.t0[c] = dt

                if "rack" in r['category']:
                    break

            print("\n\n>> Took t0 from cell fill record")
            for c, dt in self.t0.items():
                print("--- t0 for cell well %s = %s" % (c, dt))

            self.last_digest["th"] = 0

            for i,r in self.last_digest.iterrows():
                    c = r["well from"]
                    if c not in self.t0:
                        c = self.run.counter2cell(c)
                        self.last_digest.loc[i, 'well from'] = c
                    dt = datetime.strptime(r["datetime"], "%m/%d/%Y %H:%M:%S")
                    dt -= self.t0[c]
                    self.last_digest.loc[i, 'th'] = dt.total_seconds()/3600

            f = os.path.join(self.exp,"ASDigest_vols_combined.csv")

            try: 
                self.last_digest.to_csv(f, index=False)
                print(">> Combined digest files to %s" % f)
            except Exception as e:
                print(">> Cannot combine files, errpr = %s" % e)
            return 1
        else:
            print(">> Did not find ASDigest log files to consolidate, abort")

        return 0


    def add_ICP_records(self):

        try: 
            self.last_digest = pd.read_csv(os.path.join(self.exp, "ASDigest_vols_combined.csv"))
            self.log = pd.read_csv(os.path.join(self.exp, "AS_sequence_log.csv"))
        except:
            print(">> Cannot find combined ASDigest and/or sequence log files, abort")
            return 0

        print("\n\n>> Using AS_sequence_log.csv file to add ICP records to AS digests\n")

        flag=0

        for _, r in self.log.iterrows():
            container = r["container"]
            if "rack" in r["category"]:
                files = glob(os.path.join(self.exp,"run_%s_*_converted.csv" % container))
                if files:
                    print("\n>> Processing container %s: %d file(s))" % (container,len(files)))
                    for f in files:
                        print(">> add record from %s" % os.path.basename(f))
                        df = pd.read_csv(f)
                        df['Date'] += ' ' + df['Time']
                        df.rename(columns={'Date': 'analyzed'}, inplace=True)
                        df.drop(columns=['Time'], inplace=True)
                        if flag==0:
                            flag=1
                            for col in df.columns:
                                if col != 'Sample' and col not in self.last_digest.columns:
                                    self.last_digest[col] = None

                        for _, row in df.iterrows():
                            sample = row['Sample']
                            c = (self.last_digest['sample'] == sample)
                            m = self.last_digest[c].shape[0]

                            if m: 
                                if m==1:  print(sample, m)
                                else: print(sample, m, " ***** ")

                                for col in df.columns:
                                    if col != 'Sample': 
                                        self.last_digest.loc[c, col] = row[col]

        if flag==0: 
            print(">> No ICP analysis files to add, abort")
            return 0
        
        f = os.path.join(self.exp,"ASDigest_vols_w_ICP.csv")
        self.last_digest.to_csv(f, index=False)

        os.makedirs(self.exp, exist_ok=True)

        print("\n>> Grouping by cells")
        grouped = self.last_digest.groupby(['plate from', 'well from'])

        for (plate, well), group in grouped:
            print(">> Extracted %s, %s" % (plate, well))

            group = group.drop(columns=['index', 'plate from', 'plate to', "well from",
                                        "well to", "datetime", "analyzed", "method",
                                        "container", "library"])


            c = self.run.cell2counter(well)
            ID = "%s:%s" % (plate, c)

            if self.c0:
                for q in self.c0: # for each cell fill, add estimated feed concentrations
                    c0 = self.c0[q]
                    if ID in c0: 
                        u = c0[ID]
                        f=  os.path.join(self.results, "%s-%s-%s.json" % (plate, well, q))
                        with open(f, 'w') as j:
                            json.dump(u, j, indent=4)
                        if "constitution" in u:
                            for el, conc in u["constitution"].items():
                                label = "%s, mM (feed)" % el
                                if label not in group.columns:
                                    group[label] = None
                                group.loc[group['feed'] == q, label] = conc

            f=  os.path.join(self.results, "%s-%s.csv" % (plate, well))
            group['feed'] = pd.factorize(group['feed'])[0]
            group = group.dropna(subset=['kind'])
            group.insert(0, 'th', group.pop('th'))
            group.to_csv(f, index=False)

        return 1

if __name__ == "__main__":
    seq  = CustomSequence()

